﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reflection.Metadata;

namespace warOfNic 
{

    //Infantry class
    class Infantry
    {
        public int amount = 5000;
        public double range = 0.75;
        public double speed = 1;
        public double breakthrough = 1.25;
        public int takenAmount = 0;
        public int recruited = 0;
        //AI code
        public int Ai()
        {
            Random ai = new Random();
            int taken;
            if (amount >= 1000)
            {
                taken = ai.Next(0, 1001);
                amount -= taken;
                takenAmount += taken;
            }
            else if (amount < 1000)
            {
                taken = ai.Next(0, amount + 1);
                amount -= taken;
                takenAmount += taken;
            }
            return takenAmount;
        }
        public int Recruit(int x)
        {
            Random recruit = new Random();
            recruited += recruit.Next(1, x + 1);
            return recruited;
        }
    }
    //Cavalry class
    class Cavalry
    {
        public int amount = 2000;
        public double range = 1;
        public double speed = 1.25;
        public double breakthrough = 0.75;
        public int takenAmount = 0;
        public int recruited = 0;
        //AI code
        public int Ai()
        {
            Random ai = new Random();
            int taken;
            if (amount >= 1000)
            {
                taken = ai.Next(0, 1001);
                amount -= taken;
                takenAmount += taken;
            }
            else if (amount < 1000)
            {
                taken = ai.Next(0, amount + 1);
                amount -= taken;
                takenAmount += taken;
            }
            return takenAmount;
        }
        public int Recruit(int x)
        {
            Random recruit = new Random();
            recruited += recruit.Next(1, x + 1);
            return recruited;
        }
    }
    //Archers class
    class Archers
    {
        public int amount = 3000;
        public double range = 1.25;
        public double speed = 0.75;
        public double breakthrough = 1;
        public int takenAmount = 0;
        public int recruited = 0;
        //AI code
        public int Ai()
        {
            Random ai = new Random();
            int taken;
            if (amount >= 1000)
            {
                taken = ai.Next(0, 1001);
                amount -= taken;
                takenAmount += taken;
            }
            else if (amount < 1000)
            {
                taken = ai.Next(0, amount + 1);
                amount -= taken;
                takenAmount += taken;
            }
            return takenAmount;
        }
        public int Recruit(int x)
        {
            Random recruit = new Random();
            recruited += recruit.Next(1, x + 1);
            return recruited;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Character naming. I don't know why I added this, since it isn't used
            Console.WriteLine("Name your Character:");
            Console.WriteLine();
            string name = Console.ReadLine();
            Console.Clear();
            //All the "randomly generated" titles and sleepStates
            string[] title = { "the Great", "the Wise", "the Eternal", "the Powerful", "the Dictator", "the Lazy", "the Weak", "the Inbred" };
            string[] sleepState = { "joyful", "regular", "scary", "stressful", "hopeful", "tiredsome" };
            //rng
            Random rng = new Random();

            //All the funny numbers that make this pile of shit work
            int ap = 5;
            bool hasEvent = false;
            Archers archers_a = new Archers();
            Infantry infantry_a = new Infantry();
            Cavalry cavalry_a = new Cavalry();
            Archers archers_b = new Archers();
            Infantry infantry_b = new Infantry();
            Cavalry cavalry_b = new Cavalry();
            int army_a = archers_a.amount + infantry_a.amount + cavalry_a.amount;
            int date = 1;
            int unrest = 5;
            int province_a = 50;
            int province_b = 50;
            int recruitment_a = (1000 * province_a) / 10;
            int recruitment_b = (1000 * province_b) / 10;
            int recruitmentChance_a = rng.Next(1, recruitment_a + 1);
            int recruitmentChance_b = rng.Next(1, recruitment_b + 1);
            int recruitable_a = recruitment_a;
            int recruitable_b = recruitment_b;
            bool memeMode = false;

            bool atk_a = false;
            bool def_a = false;

            //Lore explanation
            Console.WriteLine("You are King " + name + " " + title[rng.Next(title.Length)] + " of the Kingdom of Nic. The Kingdom currently finds itself at war with the Kingdom of Cos.");
            Console.WriteLine("The war has no clear winner yet.");
            Console.WriteLine();
            Console.WriteLine("Press Enter to continue");
            Console.ReadLine();
            Console.Clear();
            Thread.Sleep(500);

            //The game
            do
            {
                // Ending 1
                if (province_a <= 0)
                {
                    Console.WriteLine("'The war has been lost, our Kingdom is in shambles.'");
                    break;
                }
                //Ending 2
                else if (province_b <= 0)
                {
                    Console.WriteLine("'The war has been won. The great Kingdom of Nic and King " + name + " the Bane of Cos shall rule for a thousand years.'");
                    break;
                }
                //Ending 3
                else if (unrest == 100)
                {
                    Console.WriteLine("'The peasants have revolted and are currently marching on the castle. We cannot defend against them.'");
                    break;
                }
                else if (date == 50)
                {
                    Console.Write("'The war has gone for long enough with both sides not collapsing, the Kingdom of Cos has given us a peace deal. It says that ");
                    //Ending 4 A
                    if (province_b > 50)
                    {
                        Console.Write("we should give them the provinces they occupy and end this pointless war. Should we accept this offer?'");
                        break;
                    }
                    //Ending 4 B
                    else if (province_a > 50)
                    {
                        Console.Write("they are willing to give us the provinces we occupy in exchange for a peace deal. Should we accept this offer?'");
                        break;
                    }
                    //Ending 4 C
                    else if (province_a == 50 && province_b == 50)
                    {
                        Console.Write("they are willing to settle for a white peace to end this bloodshed. Should we accept this offer?'");
                        break;
                    }
                }
                else
                {
                    Console.WriteLine("You are currently in your bedroom after a " + sleepState[rng.Next(sleepState.Length)] + " sleep.");
                    Console.WriteLine("What will you do?");
                    do
                    {


                        Console.WriteLine("Current Actions: War Room, Date/date, Unrest/unrest, Sleep/sleep");
                        //If ap is below 0, set ap to 0
                        if (ap < 0)
                        {
                            ap = 0;
                        }
                        //Events
                        if (hasEvent == true)
                        {
                            int eventRandom = rng.Next(1, 8);
                            if (province_a <= 10 || province_b <= 10)
                            {
                                eventRandom = rng.Next(1, 10);
                            }
                            if (eventRandom == 1)
                            {
                                var inflost = infantry_a.amount / 5;
                                var cavlost = cavalry_a.amount / 5;
                                var arclost = archers_a.amount / 5;
                                var lost = inflost + cavlost + arclost;
                                if (inflost < 0)
                                {
                                    inflost = 0;
                                }
                                if (cavlost < 0)
                                {
                                    cavlost = 0;
                                }
                                if (arclost < 0)
                                {
                                    arclost = 0;
                                }
                                Console.WriteLine("Peasants have decided to rebel from serfdom, you lose " + lost + " divisions");
                                infantry_a.amount -= inflost;
                                cavalry_a.amount -= cavlost;
                                archers_a.amount -= arclost;
                                if (infantry_a.amount < 0)
                                {
                                    infantry_a.amount = 0;
                                }
                                if (cavalry_a.amount < 0)
                                {
                                    cavalry_a.amount = 0;
                                }
                                if (archers_a.amount < 0)
                                {
                                    archers_a.amount = 0;
                                }
                                army_a = infantry_a.amount + cavalry_a.amount + archers_a.amount;
                                hasEvent = false;
                            }
                            else if (eventRandom == 2)
                            {
                                var apGain = ap - 3;
                                Console.WriteLine("You had a very good rest. You gained " + apGain + " Action Points");
                                ap += apGain;
                                hasEvent = false;
                            }
                            else if (eventRandom == 3)
                            {
                                var apLost = ap - 3;
                                Console.WriteLine("You had a terrible night. You lose " + apLost + " Action Points");
                                ap -= apLost;
                                hasEvent = false;
                            }
                            else if (eventRandom == 4)
                            {
                                var recGain = (recruitable_a * province_a) / 75;
                                Console.WriteLine("You managed to recruit additional volunteers. You gain additional " + recGain + " volunteers");
                                recruitable_a += recGain;
                                hasEvent = false;
                            }
                            else if (eventRandom == 5)
                            {
                                var recLost = (recruitable_a * province_a) / 75;
                                Console.WriteLine("You failed in getting some volunteers. You miss " + recLost + " volunteers");
                                recruitable_a -= recLost;
                                hasEvent = false;
                            }
                            else if (eventRandom == 6)
                            {
                                Console.WriteLine("Some new reforms made the peasants happier. You lose 10 unrest.");
                                unrest -= 10;
                                hasEvent = false;
                            }
                            else if (eventRandom == 7)
                            {
                                Console.WriteLine("A new reform made the peasants unhappy. You gain 10 unrest");
                                unrest += 10;
                                hasEvent = false;
                            }
                            else if (province_a <= 10 && eventRandom == 8)
                            {
                                int provinceGain = rng.Next(1, 6);
                                var inflost = infantry_a.amount / 5;
                                var cavlost = cavalry_a.amount / 5;
                                var arclost = archers_a.amount / 5;
                                if (inflost < 0)
                                {
                                    inflost = 0;
                                }
                                if (cavlost < 0)
                                {
                                    cavlost = 0;
                                }
                                if (arclost < 0)
                                {
                                    arclost = 0;
                                }
                                var lost = inflost + cavlost + arclost;
                                Console.WriteLine("You order a final counter-offensive. You manage to regain " + provinceGain + " provinces, however you lose " + lost + " men");
                                province_a += provinceGain;
                                province_b -= provinceGain;
                                infantry_a.amount -= inflost;
                                cavalry_a.amount -= cavlost;
                                archers_a.amount -= arclost;
                                if (infantry_a.amount < 0)
                                {
                                    infantry_a.amount = 0;
                                }
                                if (cavalry_a.amount < 0)
                                {
                                    cavalry_a.amount = 0;
                                }
                                if (archers_a.amount < 0)
                                {
                                    archers_a.amount = 0;
                                }
                                army_a = infantry_a.amount + cavalry_a.amount + archers_a.amount;
                                hasEvent = false;
                            }
                            else if (province_a <= 10 && eventRandom == 9)
                            {
                                var inflost = infantry_a.amount / 5;
                                var cavlost = cavalry_a.amount / 5;
                                var arclost = archers_a.amount / 5;
                                if (inflost < 0)
                                {
                                    inflost = 0;
                                }
                                if (cavlost < 0)
                                {
                                    cavlost = 0;
                                }
                                if (arclost < 0)
                                {
                                    arclost = 0;
                                }
                                var lost = inflost + cavlost + arclost;
                                Console.WriteLine("You order a final counter-offensive. It fails and you lose " + lost + " men");
                                infantry_a.amount -= inflost;
                                cavalry_a.amount -= cavlost;
                                archers_a.amount -= arclost;
                                if (infantry_a.amount < 0)
                                {
                                    infantry_a.amount = 0;
                                }
                                if (cavalry_a.amount < 0)
                                {
                                    cavalry_a.amount = 0;
                                }
                                if (archers_a.amount < 0)
                                {
                                    archers_a.amount = 0;
                                }
                                army_a = infantry_a.amount + cavalry_a.amount + archers_a.amount;
                                hasEvent = false;
                            }
                            else if (province_b <= 10 && eventRandom == 8)
                            {
                                int provinceGain = rng.Next(1, 6);
                                var inflost = infantry_a.amount / 5;
                                var cavlost = cavalry_a.amount / 5;
                                var arclost = archers_a.amount / 5;
                                if (inflost < 0)
                                {
                                    inflost = 0;
                                }
                                if (cavlost < 0)
                                {
                                    cavlost = 0;
                                }
                                if (arclost < 0)
                                {
                                    arclost = 0;
                                }
                                var lost = inflost + cavlost + arclost;
                                Console.WriteLine("They order a final counter-offensive. It succeeds and they regain "+ provinceGain + " proinvces, you lose " + lost + " men");
                                province_a -= provinceGain;
                                province_b += provinceGain;
                                infantry_a.amount -= inflost;
                                cavalry_a.amount -= cavlost;
                                archers_a.amount -= arclost;
                                if (infantry_a.amount > 0)
                                {
                                    infantry_a.amount = 0;
                                }
                                if (cavalry_a.amount > 0)
                                {
                                    cavalry_a.amount = 0;
                                }
                                if (archers_a.amount > 0)
                                {
                                    archers_a.amount = 0;
                                }
                                army_a = infantry_a.amount + cavalry_a.amount + archers_a.amount;
                                hasEvent = false;
                            }
                            else if (province_b <= 10 && eventRandom == 9)
                            {
                                var inflost = infantry_a.amount / 5;
                                var cavlost = cavalry_a.amount / 5;
                                var arclost = archers_a.amount / 5;
                                if (inflost < 0)
                                {
                                    inflost = 0;
                                }
                                if (cavlost < 0)
                                {
                                    cavlost = 0;
                                }
                                if (arclost < 0)
                                {
                                    arclost = 0;
                                }
                                var lost = inflost + cavlost + arclost;
                                Console.WriteLine("They order a final counter-offensive. It fails, however you lose " + lost + " men");
                                infantry_a.amount -= inflost;
                                cavalry_a.amount -= cavlost;
                                archers_a.amount -= arclost;
                                if (infantry_a.amount < 0)
                                {
                                    infantry_a.amount = 0;
                                }
                                if (cavalry_a.amount < 0)
                                {
                                    cavalry_a.amount = 0;
                                }
                                if (archers_a.amount < 0)
                                {
                                    archers_a.amount = 0;
                                }
                                army_a = infantry_a.amount + cavalry_a.amount + archers_a.amount;
                                hasEvent = false;
                            }
                        }
                        //How many things you can do each turn
                        Console.WriteLine("You have " + ap + " Action Points");
                        Console.WriteLine();
                        string choice = Console.ReadLine();
                        // The "War Room"
                        if (choice == "War Room" || choice == "war room")
                        {
                            Thread.Sleep(1000);
                            do
                            {
                                Console.WriteLine();
                                Console.WriteLine("Current Actions: Detail/detail, Attack/attack, Defend/defend, Back/back");
                                Console.WriteLine("You are in the War Room, here you can command your army.");
                                Console.WriteLine("You currently have " + army_a + " men available.");
                                Console.WriteLine("What will you do?");
                                Console.WriteLine();
                                string a = Console.ReadLine();         
                                //Detail, where you can see the amount of men you have,and recruit
                                if (a == "Detail" || a == "detail")
                                {
                                    Console.WriteLine("Current Actions: Recruit/recruit, Back/back");
                                    Console.WriteLine("Your army consists of:");
                                    Console.WriteLine(infantry_a.amount + " Infantry");
                                    Console.WriteLine(cavalry_a.amount + " Cavalry");
                                    Console.WriteLine(archers_a.amount + " Archers");
                                    Console.WriteLine();
                                    Console.WriteLine("'We have " + province_a + " provinces, and our enemy has " + province_b + " provinces'");
                                    Console.WriteLine("What will you do?");
                                    Console.WriteLine();
                                    string b = Console.ReadLine();
                                    //Recruitment
                                    if (b == "Recruit" && !(ap <= 0) || b == "recruit" && !(ap <= 0))
                                    {
                                        Console.WriteLine("Current Actions: [I/i]nfantry, [A/a]rchers, [C/c]avalry, Back/back");
                                        Console.WriteLine("Here you can recruit divisions");
                                        Console.WriteLine("Write the first letter of the division you want to recruit");
                                        Console.WriteLine("You have " + recruitable_a + " volunteers available");
                                        Console.WriteLine("What will you do?");
                                        Console.WriteLine();
                                        string c = Console.ReadLine();
                                        // Infantry Recruitment
                                        if (c == "I" || c == "i")
                                        {
                                            Console.WriteLine("Here you can recruit infantry");
                                            Console.WriteLine("Currently you have: " + infantry_a.amount + " infantry");
                                            Console.WriteLine("You can only recruit 1-" + recruitable_a + " division at a time");
                                            var d = Convert.ToInt32(Console.ReadLine());
                                            if (d > 0 && d < recruitable_a + 1)
                                            {
                                                infantry_a.amount = d + infantry_a.amount;
                                                recruitable_a -= d;
                                                ap--;
                                                army_a = archers_a.amount + infantry_a.amount + cavalry_a.amount;
                                            }
                                            else
                                            {
                                                Console.WriteLine("Invalid input");
                                            }
                                        }
                                        //Archers Recruitment
                                        else if (c== "A" || c == "a")
                                        {
                                            Console.WriteLine("Here you can recruit archers");
                                            Console.WriteLine("Currently you have: " + archers_a.amount + " archers");
                                            Console.WriteLine("You can only recruit 1-" + recruitable_a + " division at a time");
                                            var d = Convert.ToInt32(Console.ReadLine());
                                            if (d > 0 && d < recruitable_a + 1)
                                            {
                                                archers_a.amount = d + archers_a.amount;
                                                recruitable_a -= d;
                                                ap--;
                                                army_a = archers_a.amount + infantry_a.amount + cavalry_a.amount;
                                            }
                                            else
                                            {
                                                Console.WriteLine("Invalid input");
                                            }
                                        }
                                        //Cavalry Recruitment
                                        else if (c == "C" || c == "c")
                                        {
                                            Console.WriteLine("Here you can recruit cavalry");
                                            Console.WriteLine("Currently you have: " + cavalry_a.amount + " cavalry");
                                            Console.WriteLine("You can only recruit 1-" + recruitable_a + " division at a time");
                                            var d = Convert.ToInt32(Console.ReadLine());
                                            if (d > 0 && d < recruitable_a + 1)
                                            {
                                                cavalry_a.amount = d + cavalry_a.amount;
                                                recruitable_a -= d;
                                                ap--;
                                                army_a = archers_a.amount + infantry_a.amount + cavalry_a.amount;
                                            }
                                            else
                                            {
                                                Console.WriteLine("Invalid input");
                                            }
                                        }

                                    }
                                    else if (b == "Back" || b == "back")
                                    {
                                        break;
                                    }
                                    else if (ap <= 0)
                                    {
                                        Console.WriteLine("You are too tired");
                                        break;
                                    }
                                    else
                                    {
                                        Console.WriteLine("Invalid input");
                                    }
                                }
                                //Attack
                                else if (a == "Attack" && !(ap <= 0) || a == "attack" && !(ap <= 0))
                                {

                                    Console.WriteLine("Current Actions: [I/i]nfantry, [C/c]avalry, [A/a]rchers, Back/back");
                                    Console.WriteLine("Here you can choose which divisions will attack");
                                    Console.WriteLine("Write the first letter of the division you want to attack");
                                    Console.WriteLine("What will you do?");
                                    Console.WriteLine();
                                    string attack = Console.ReadLine();
                                    do
                                    {
                                        //Infantry Attack
                                        if (attack == "I" || attack == "i")
                                        {
                                            Console.WriteLine("How many divisions do you want to attack");
                                            Console.WriteLine("Currently you have " + infantry_a.amount + " Infantry available");
                                            Console.WriteLine("You can only put 1 - 1000 infantry");
                                            Console.WriteLine();
                                            int amount = Convert.ToInt32(Console.ReadLine());
                                            if (amount > 0 && amount < 1001 && infantry_a.amount > amount)
                                            {
                                                infantry_a.takenAmount += amount;
                                                infantry_a.amount -= amount;
                                                atk_a = true;
                                                ap--;
                                                army_a = infantry_a.amount + cavalry_a.amount + archers_a.amount;
                                                break;
                                            }
                                            else
                                            {
                                                Console.WriteLine("Invalid input");
                                            }
                                        }
                                        //Cavarly Attack
                                        else if (attack == "C" || attack == "c")
                                        {
                                            Console.WriteLine("How many divisions do you want to attack");
                                            Console.WriteLine("Currently you have " + cavalry_a.amount + " Cavalry available");
                                            Console.WriteLine("You can only put 1 - 1000 cavalry");
                                            Console.WriteLine();
                                            int amount = Convert.ToInt32(Console.ReadLine());
                                            if (amount > 0 && amount < 1001 && cavalry_a.amount > amount)
                                            {
                                                cavalry_a.takenAmount += amount;
                                                cavalry_a.amount -= amount;
                                                atk_a = true;
                                                ap--;
                                                army_a = infantry_a.amount + cavalry_a.amount + archers_a.amount;
                                                break;
                                            }
                                            else
                                            {
                                                Console.WriteLine("Invalid input");
                                            }
                                        }
                                        //Archers Attack
                                        else if (attack == "A" || attack == "a")
                                        {
                                            Console.WriteLine("How many divisions do you want to attack");
                                            Console.WriteLine("Currently you have " + archers_a.amount + " Archers available");
                                            Console.WriteLine("You can only put 1 - 1000 archers");
                                            Console.WriteLine();
                                            int amount = Convert.ToInt32(Console.ReadLine());
                                            if (amount > 0 && amount < 1001 && archers_a.amount > amount)
                                            {
                                                archers_a.takenAmount += amount;
                                                archers_a.amount -= amount;
                                                atk_a = true;
                                                ap--;
                                                army_a = infantry_a.amount + cavalry_a.amount + archers_a.amount;
                                                break;
                                            }
                                            else
                                            {
                                                Console.WriteLine("Invalid input");
                                            }
                                        }
                                        else if (attack == "Back" || attack == "back")
                                        {
                                            break;
                                        }
                                        else
                                        {
                                            Console.WriteLine("Invalid input");
                                            attack = Console.ReadLine();
                                        }
                                    } while (true);

                                }
                                //Defend
                                else if (a == "Defend" && !(ap <= 0) || a == "defend" && !(ap <= 0))
                                {

                                    Console.WriteLine("Current Actions: [I/i]nfantry, [C/c]avalry, [A/a]rchers, Back/back");
                                    Console.WriteLine("Here you can choose which divisions will defend");
                                    Console.WriteLine("Write the first letter of the division you want to defend");
                                    Console.WriteLine("What will you do?");
                                    Console.WriteLine();
                                    string attack = Console.ReadLine();
                                    do
                                    {
                                        //Infantry Defend
                                        if (attack == "I" || attack == "i")
                                        {
                                            Console.WriteLine("How many divisions do you want to defend");
                                            Console.WriteLine("Currently you have " + infantry_a.amount + " Infantry available");
                                            Console.WriteLine("You can only put 1 - 1000 infantry");
                                            Console.WriteLine();
                                            int amount = Convert.ToInt32(Console.ReadLine());
                                            if (amount > 0 && amount < 1001 && infantry_a.amount > amount)
                                            {
                                                infantry_a.takenAmount += amount;
                                                infantry_a.amount -= amount;
                                                def_a = true;
                                                ap--;
                                                army_a = infantry_a.amount + cavalry_a.amount + archers_a.amount;
                                                break;
                                            }
                                            else
                                            {
                                                Console.WriteLine("Invalid input");
                                            }
                                        }
                                        //Cavalry Defend
                                        else if (attack == "C" || attack == "c")
                                        {
                                            Console.WriteLine("How many divisions do you want to defend");
                                            Console.WriteLine("Currently you have " + cavalry_a.amount + " Cavalry available");
                                            Console.WriteLine("You can only put 1 - 1000 cavalry");
                                            Console.WriteLine();
                                            int amount = Convert.ToInt32(Console.ReadLine());
                                            if (amount > 0 && amount < 1001 && cavalry_a.amount > amount)
                                            {
                                                cavalry_a.takenAmount += amount;
                                                cavalry_a.amount -= amount;
                                                def_a = true;
                                                ap--;
                                                army_a = infantry_a.amount + cavalry_a.amount + archers_a.amount;
                                                break;
                                            }
                                            else
                                            {
                                                Console.WriteLine("Invalid input");
                                            }
                                        }
                                        //Archers Defend
                                        else if (attack == "A" || attack == "a")
                                        {
                                            Console.WriteLine("How many divisions do you want to defend");
                                            Console.WriteLine("Currently you have " + archers_a.amount + " Archers available");
                                            Console.WriteLine("You can only put 1 - 1000 archers");
                                            Console.WriteLine();
                                            int amount = Convert.ToInt32(Console.ReadLine());
                                            if (amount > 0 && amount < 1001 && archers_a.amount > amount)
                                            {
                                                archers_a.takenAmount += amount;
                                                archers_a.amount -= amount;
                                                def_a = true;
                                                ap--;
                                                army_a = infantry_a.amount + cavalry_a.amount + archers_a.amount;
                                                break;
                                            }
                                            else
                                            {
                                                Console.WriteLine("Invalid input");
                                            }
                                        }
                                        else if (ap <= 0)
                                        {
                                            Console.WriteLine("You are too tired");
                                        }
                                        else
                                        {
                                            Console.WriteLine("Invalid input");
                                            attack = Console.ReadLine();
                                        }
                                    } while (true);
                                } 
                                //If not enough ap
                                else if (a == "Attack" && ap <= 0 || a == "attack" && ap <= 0)
                                {
                                    Console.WriteLine("You are too tired");
                                }
                                else if (a == "Defend" && ap <= 0 || a == "defend" && ap <= 0)
                                {
                                    Console.WriteLine("You are too tired");
                                }
                                else if (a == "Back" || a == "back")
                                {
                                    Thread.Sleep(1000);
                                    break;
                                    
                                }
                                else
                                {
                                    Console.WriteLine("Invalid input");
                                }
                            }while(true);
                        }
                        //What turn are you on
                        else if (choice == "Date" || choice == "date")
                        {
                            Console.WriteLine("It's day " + date + " of the war.");
                            Console.WriteLine();
                        }
                        //Unrest
                        else if (choice == "Unrest" || choice == "unrest")
                        {
                            do
                            {
                                //What unrest level are you on
                                Console.WriteLine("Current Actions: Supress/supress, Punish/punish, Amend/amend, Argue/argue, Back/back");
                                Console.WriteLine("Current unrest level is: " + unrest);
                                if (unrest <= 25)
                                {
                                    Console.WriteLine("The peasants are content with your rule and dont mind the war");
                                }
                                else if (unrest >= 25 && unrest <= 50)
                                {
                                    Console.WriteLine("The peasants are complaining about the war");
                                }
                                else if (unrest >= 50 && unrest <= 75)
                                {
                                    Console.WriteLine("The peasants are actively boycotting your rule");
                                }
                                else if (unrest >= 75 && unrest <= 100)
                                {
                                    Console.WriteLine("The peasants are organising into militia groups against your rule");
                                }
                                Console.WriteLine("What will you do?");
                                Console.WriteLine();
                                string a = Console.ReadLine();
                                //Supress
                                if (a == "Supress" && !(ap <= 0) || a == "supress" && !(ap <= 0))
                                {
                                    var rand = rng.Next(0, 3);
                                    if (rand == 0)
                                    {
                                        Console.WriteLine("The peasants have been successfully supressed");
                                        if (unrest > 0)
                                        {
                                            ap--;
                                            unrest -= 5;
                                            if (unrest < 0)
                                            {
                                                unrest = 0;
                                            }
                                        }
                                        
                                    }
                                    else if (rand == 1)
                                    {
                                        Console.WriteLine("The peasants have not been supressed");
                                        ap--;
                                    }
                                    else if (rand == 2)
                                    {
                                        Console.WriteLine("The peasants resited your supression effort");
                                        if (unrest != 100)
                                        {
                                            ap--;
                                            unrest += 5;
                                        }
                                    }
                                    //A joke
                                    else
                                    {
                                        Console.WriteLine("Pierdol sie");
                                        ap = -10;
                                    }
                                }
                                //Punish
                                else if (a == "Punish" && !(ap <= 0) || a == "punish" && !(ap <= 0))
                                {
                                    var rand = rng.Next(0, 3);
                                    if (rand == 0)
                                    {
                                        Console.WriteLine("The peasants have been successfully punished");
                                        if (unrest > 0)
                                        {
                                            ap -= 2;
                                            unrest -= 10;
                                            if (unrest < 0)
                                            {
                                                unrest = 0;
                                            }
                                        }

                                    }
                                    else if (rand == 1)
                                    {
                                        Console.WriteLine("The peasants have not been punished");
                                        ap -= 2;
                                    }
                                    else if (rand == 2)
                                    {
                                        Console.WriteLine("The peasants resited your punishment effort");
                                        if (unrest != 100)
                                        {
                                            ap -= 2;
                                            unrest += 10;
                                        }
                                    }
                                }
                                //Amend
                                else if (a == "Amend" && !(ap <= 0) || a == "amend" && !(ap <= 0))
                                {
                                    var rand = rng.Next(0, 2);
                                    if (rand == 0)
                                    {
                                        Console.WriteLine("The peasants have accepted your amendation efforts");
                                        if (unrest > 0)
                                        {
                                            ap -= 2;
                                            unrest -= 10;
                                            if (unrest < 0)
                                            {
                                                unrest = 0;
                                            }
                                        }

                                    }
                                    else if (rand == 1)
                                    {
                                        Console.WriteLine("The peasants dislike your amendation efforts");
                                        if (unrest != 100)
                                        {
                                            ap -= 2;
                                            unrest += 10;

                                        }
                                    }
                                }
                                //Argue
                                else if (a == "Argue" && !(ap <= 0) || a == "argue" && !(ap <= 0))
                                {
                                    var rand = rng.Next(0, 2);
                                    if (rand == 0)
                                    {
                                        Console.WriteLine("The peasants Have been turned by your arguments");
                                        if (unrest > 0)
                                        {
                                            ap--;
                                            unrest -= 5;
                                            if (unrest < 0)
                                            {
                                                unrest = 0;
                                            }
                                        }

                                    }
                                    else if (rand == 1)
                                    {
                                        Console.WriteLine("The peasants don't care for your arguments");
                                        ap--;
                                    }
                                }
                                else if (a == "Back" || a == "back")
                                {
                                    break;
                                }
                                else if (ap <= 0)
                                {
                                    Console.WriteLine("You are too tired");
                                }
                            } while(true);
                        }
                        //Meme mode
                        else if (choice == "meme" || choice == "Meme")
                        {
                            if (memeMode == true)
                            {
                                Console.WriteLine("Current commands are:");
                                Console.WriteLine("Sex");
                                Console.WriteLine("Hoi");
                                Console.WriteLine("Fumo");
                                Console.WriteLine("Wock");
                            }
                            else
                            {
                                Console.WriteLine("Are you sure you want to activate meme mode? It will break your game");
                                Console.WriteLine("Y/N");
                                Console.WriteLine();
                                do
                                {
                                    string meem = Console.ReadLine();
                                    if (meem == "y" || meem == "Y")
                                    {
                                        Console.WriteLine("New commands activated");
                                        memeMode = true;
                                        break;
                                    }
                                    else if (meem == "n" || meem == "N")
                                    {
                                        break;
                                    }
                                } while (true);
                            }
                            
                        }
                        
                        //End turn... this is the reason it doesn't launch quickly
                        else if (choice == "Sleep" || choice == "sleep")
                        {
                            Console.WriteLine("You go to sleep");
                            //Resets the values, and adds unrest and date
                            ap = 5;
                            date++;
                            unrest += 5;
                            //Please kill me
                            int atk_b = rng.Next(0, 2);
                            int def_b = rng.Next(0, 2);
                            int rec = rng.Next(0, 8);
                            //Random chance of an event
                            int eventer = rng.Next(0, 2);

                            if (eventer == 1)
                            {
                                hasEvent = true;
                            }

                            //This code lets the enemy recruit divisions
                            var infrec = infantry_b.Recruit(recruitable_b);
                            recruitable_b -= infrec;
                            var cavrec = cavalry_b.Recruit(recruitable_b);
                            recruitable_b -= cavrec;
                            var arcrec = archers_b.Recruit(recruitable_b);
                            recruitable_b -= arcrec;
                            //Checks what to recruit
                            if (rec == 1)
                            {
                                infantry_b.amount += infrec;
                            }
                            else if (rec == 2)
                            {
                                cavalry_b.amount += cavrec;
                            }
                            else if (rec == 3)
                            {
                                archers_b.amount += arcrec;
                            }
                            else if (rec == 4)
                            {
                                infantry_b.amount += infrec;

                                cavalry_b.amount += cavrec;

                            }
                            else if (rec == 5)
                            {
                                infantry_b.amount += infrec;

                                archers_b.amount += arcrec;
                            }
                            else if (rec == 6)
                            {
                                cavalry_b.amount += cavrec;

                                archers_b.amount += arcrec;
                            }
                            else if (rec == 7)
                            {
                                infantry_b.amount += infrec;

                                cavalry_b.amount += cavrec;

                                archers_b.amount += arcrec;
                            }

                            //Resets values of recruitment
                            infrec = 0;
                            cavrec = 0;
                            arcrec = 0;

                            //This code adds values to infanty_b/cavalry_b/archers_b.takenAmount
                            var infai = infantry_b.Ai();
                            var cavai = cavalry_b.Ai();
                            var arcai = archers_b.Ai();

                            //This one is the check for provinces
                            var take = rng.Next(1, 7);

                            //This block checks the 'combat power' of each division of _a
                            var infbreak_a = infantry_a.takenAmount * infantry_a.breakthrough;
                            var infrange_a = infantry_a.takenAmount * infantry_a.range;
                            var infspeed_a = infantry_a.takenAmount * infantry_a.speed;
                            var cavbreak_a = cavalry_a.takenAmount * cavalry_a.breakthrough;
                            var cavrange_a = cavalry_a.takenAmount * cavalry_a.range;
                            var cavspeed_a = cavalry_a.takenAmount * cavalry_a.speed;
                            var arcbreak_a = archers_a.takenAmount * archers_a.breakthrough;
                            var arcrange_a = archers_a.takenAmount * archers_a.range;
                            var arcspeed_a = archers_a.takenAmount * archers_a.speed;
                            var totalTaken_a = infantry_a.takenAmount + cavalry_a.takenAmount + archers_a.takenAmount;


                            //This block checks the 'combat power' of each division of _b
                            var infbreak_b = infantry_b.takenAmount * infantry_b.breakthrough;
                            var infrange_b = infantry_b.takenAmount * infantry_b.range;
                            var infspeed_b = infantry_b.takenAmount * infantry_b.speed;
                            var cavbreak_b = cavalry_b.takenAmount * cavalry_b.breakthrough;
                            var cavrange_b = cavalry_b.takenAmount * cavalry_b.range;
                            var cavspeed_b = cavalry_b.takenAmount * cavalry_b.speed;
                            var arcbreak_b = archers_b.takenAmount * archers_b.breakthrough;
                            var arcrange_b = archers_b.takenAmount * archers_b.range;
                            var arcspeed_b = archers_b.takenAmount * archers_b.speed;
                            var totalTaken_b = infantry_b.takenAmount + cavalry_b.takenAmount + archers_b.takenAmount;

                            //Is the player attacking and the AI defending?
                            if (atk_a == true && def_b == 1)
                            {
                                //How much 'combat power' has been lost
                                double lostinf_a = infbreak_a - infbreak_b;
                                double lostinf2_a = infrange_a - infrange_b;
                                double lostinf3_a = infspeed_a - infspeed_b;
                                double lostinf4_a = infbreak_a - cavbreak_b;
                                double lostinf5_a = infrange_a - cavrange_b;
                                double lostinf6_a = infspeed_a - cavspeed_b;
                                double lostinf7_a = infbreak_a - arcbreak_b;
                                double lostinf8_a = infrange_a - arcrange_b;
                                double lostinf9_a = infspeed_a - arcspeed_b;
                                double lostcav_a = cavbreak_a - infbreak_b;
                                double lostcav2_a = cavrange_a - infrange_b;
                                double lostcav3_a = cavspeed_a - infspeed_b;
                                double lostcav4_a = cavbreak_a - cavbreak_b;
                                double lostcav5_a = cavrange_a - cavrange_b;
                                double lostcav6_a = cavspeed_a - cavspeed_b;
                                double lostcav7_a = cavbreak_a - arcbreak_b;
                                double lostcav8_a = cavrange_a - arcrange_b;
                                double lostcav9_a = cavspeed_a - arcspeed_b;
                                double lostarc_a = arcbreak_a - infbreak_b;
                                double lostarc2_a = arcrange_a - infrange_b;
                                double lostarc3_a = arcspeed_a - infspeed_b;
                                double lostarc4_a = arcbreak_a - cavbreak_b;
                                double lostarc5_a = arcrange_a - cavrange_b;
                                double lostarc6_a = arcspeed_a - cavspeed_b;
                                double lostarc7_a = arcbreak_a - arcbreak_b;
                                double lostarc8_a = arcrange_a - arcrange_b;
                                double lostarc9_a = arcspeed_a - arcspeed_b;

                                //Returns the vaule of divisions
                                int lostinfTotal_a = (Convert.ToInt32(lostinf_a) + Convert.ToInt32(lostinf2_a) + Convert.ToInt32(lostinf3_a) + Convert.ToInt32(lostinf4_a) + Convert.ToInt32(lostinf5_a) + Convert.ToInt32(lostinf6_a) + Convert.ToInt32(lostinf7_a) + Convert.ToInt32(lostinf8_a) + Convert.ToInt32(lostinf9_a)) / 9;
                                int lostcavTotal_a = (Convert.ToInt32(lostcav_a) + Convert.ToInt32(lostcav2_a) + Convert.ToInt32(lostcav3_a) + Convert.ToInt32(lostcav4_a) + Convert.ToInt32(lostcav5_a) + Convert.ToInt32(lostcav6_a) + Convert.ToInt32(lostcav7_a) + Convert.ToInt32(lostcav8_a) + Convert.ToInt32(lostcav9_a)) / 9;
                                int lostarcTotal_a = (Convert.ToInt32(lostarc_a) + Convert.ToInt32(lostarc2_a) + Convert.ToInt32(lostarc3_a) + Convert.ToInt32(lostarc4_a) + Convert.ToInt32(lostarc5_a) + Convert.ToInt32(lostarc6_a) + Convert.ToInt32(lostarc7_a) + Convert.ToInt32(lostarc8_a) + Convert.ToInt32(lostarc9_a)) / 9;

                                //Set the value to 0 if it's below 0
                                if (lostinfTotal_a <= 0)
                                {
                                    lostinfTotal_a = 0;
                                }
                                if (lostcavTotal_a <= 0)
                                {
                                    lostcavTotal_a = 0;
                                }
                                if (lostarcTotal_a <= 0)
                                {
                                    lostarcTotal_a = 0;
                                }
                                //Takes lost(division)Total_a amount from (division)_a.takenAmount
                                infantry_a.takenAmount -= lostinfTotal_a;
                                cavalry_a.takenAmount -= lostcavTotal_a;
                                archers_a.takenAmount -= lostarcTotal_a;


                                double lostinf_b = infbreak_b - infbreak_a;
                                double lostinf2_b = infrange_b - infrange_a;
                                double lostinf3_b = infspeed_b - infspeed_a;
                                double lostinf4_b = infbreak_b - cavbreak_a;
                                double lostinf5_b = infrange_b - cavrange_a;
                                double lostinf6_b = infspeed_b - cavspeed_a;
                                double lostinf7_b = infbreak_b - arcbreak_a;
                                double lostinf8_b = infrange_b - arcrange_a;
                                double lostinf9_b = infspeed_b - arcspeed_a;
                                double lostcav_b = cavbreak_b - infbreak_a;
                                double lostcav2_b = cavrange_b - infrange_a;
                                double lostcav3_b = cavspeed_b - infspeed_a;
                                double lostcav4_b = cavbreak_b - cavbreak_a;
                                double lostcav5_b = cavrange_b - cavrange_a;
                                double lostcav6_b = cavspeed_b - cavspeed_a;
                                double lostcav7_b = cavbreak_b - arcbreak_a;
                                double lostcav8_b = cavrange_b - arcrange_a;
                                double lostcav9_b = cavspeed_b - arcspeed_a;
                                double lostarc_b = arcbreak_b - infbreak_a;
                                double lostarc2_b = arcrange_b - infrange_a;
                                double lostarc3_b = arcspeed_b - infspeed_a;
                                double lostarc4_b = arcbreak_b - cavbreak_a;
                                double lostarc5_b = arcrange_b - cavrange_a;
                                double lostarc6_b = arcspeed_b - cavspeed_a;
                                double lostarc7_b = arcbreak_b - arcbreak_a;
                                double lostarc8_b = arcrange_b - arcrange_a;
                                double lostarc9_b = arcspeed_b - arcspeed_a;

                                int lostinfTotal_b = (Convert.ToInt32(lostinf_b) + Convert.ToInt32(lostinf2_b) + Convert.ToInt32(lostinf3_b) + Convert.ToInt32(lostinf4_b) + Convert.ToInt32(lostinf5_b) + Convert.ToInt32(lostinf6_b) + Convert.ToInt32(lostinf7_b) + Convert.ToInt32(lostinf8_b) + Convert.ToInt32(lostinf9_b)) / 9;
                                int lostcavTotal_b = (Convert.ToInt32(lostcav_b) + Convert.ToInt32(lostcav2_b) + Convert.ToInt32(lostcav3_b) + Convert.ToInt32(lostcav4_b) + Convert.ToInt32(lostcav5_b) + Convert.ToInt32(lostcav6_b) + Convert.ToInt32(lostcav7_b) + Convert.ToInt32(lostcav8_b) + Convert.ToInt32(lostcav9_b)) / 9;
                                int lostarcTotal_b = (Convert.ToInt32(lostarc_b) + Convert.ToInt32(lostarc2_b) + Convert.ToInt32(lostarc3_b) + Convert.ToInt32(lostarc4_b) + Convert.ToInt32(lostarc5_b) + Convert.ToInt32(lostarc6_b) + Convert.ToInt32(lostarc7_b) + Convert.ToInt32(lostarc8_b) + Convert.ToInt32(lostarc9_b)) / 9;

                                if (lostinfTotal_b <= 0)
                                {
                                    lostinfTotal_b = 0;
                                }
                                if (lostcavTotal_b <= 0)
                                {
                                    lostcavTotal_b = 0;
                                }
                                if (lostarcTotal_b <= 0)
                                {
                                    lostarcTotal_b = 0;
                                }

                                infantry_b.takenAmount -= lostinfTotal_b;
                                cavalry_b.takenAmount -= lostcavTotal_b;
                                archers_b.takenAmount -= lostarcTotal_b;

                                //Is (division)_a.takenAmount larger than (division)_b.takenAmount?
                                if (infantry_a.takenAmount > infantry_b.takenAmount && infantry_a.takenAmount > cavalry_b.takenAmount && infantry_a.takenAmount > archers_b.takenAmount && cavalry_a.takenAmount > infantry_b.takenAmount && cavalry_a.takenAmount > cavalry_b.takenAmount && cavalry_a.takenAmount > archers_b.takenAmount && archers_a.takenAmount > infantry_b.takenAmount && archers_a.takenAmount > cavalry_b.takenAmount && archers_a.takenAmount > archers_b.takenAmount 
                                    || infantry_a.takenAmount > infantry_b.takenAmount && infantry_a.takenAmount > cavalry_b.takenAmount && infantry_a.takenAmount > archers_b.takenAmount && cavalry_a.takenAmount > infantry_b.takenAmount && cavalry_a.takenAmount > cavalry_b.takenAmount && cavalry_a.takenAmount > archers_b.takenAmount 
                                    || infantry_a.takenAmount > infantry_b.takenAmount && infantry_a.takenAmount > cavalry_b.takenAmount && infantry_a.takenAmount > archers_b.takenAmount && archers_a.takenAmount > infantry_b.takenAmount && archers_a.takenAmount > cavalry_b.takenAmount && archers_a.takenAmount > archers_b.takenAmount 
                                    || cavalry_a.takenAmount > infantry_b.takenAmount && cavalry_a.takenAmount > cavalry_b.takenAmount && cavalry_a.takenAmount > archers_b.takenAmount && archers_a.takenAmount > infantry_b.takenAmount && archers_a.takenAmount > cavalry_b.takenAmount && archers_a.takenAmount > archers_b.takenAmount 
                                    || infantry_a.takenAmount > infantry_b.takenAmount && infantry_a.takenAmount > cavalry_b.takenAmount && infantry_a.takenAmount > archers_b.takenAmount 
                                    || cavalry_a.takenAmount > infantry_b.takenAmount && cavalry_a.takenAmount > cavalry_b.takenAmount && cavalry_a.takenAmount > archers_b.takenAmount 
                                    || archers_a.takenAmount > infantry_b.takenAmount && archers_a.takenAmount > cavalry_b.takenAmount && archers_a.takenAmount > archers_b.takenAmount 
                                    || infantry_a.takenAmount > infantry_b.takenAmount && infantry_a.takenAmount > cavalry_b.takenAmount && cavalry_a.takenAmount > infantry_b.takenAmount && cavalry_a.takenAmount > cavalry_b.takenAmount && archers_a.takenAmount > infantry_b.takenAmount && archers_a.takenAmount > cavalry_b.takenAmount
                                    || infantry_a.takenAmount > infantry_b.takenAmount && infantry_a.takenAmount > cavalry_b.takenAmount && cavalry_a.takenAmount > infantry_b.takenAmount && cavalry_a.takenAmount > cavalry_b.takenAmount
                                    || infantry_a.takenAmount > infantry_b.takenAmount && infantry_a.takenAmount > cavalry_b.takenAmount && archers_a.takenAmount > infantry_b.takenAmount && archers_a.takenAmount > cavalry_b.takenAmount
                                    || cavalry_a.takenAmount > infantry_b.takenAmount && cavalry_a.takenAmount > cavalry_b.takenAmount && archers_a.takenAmount > infantry_b.takenAmount && archers_a.takenAmount > cavalry_b.takenAmount
                                    || infantry_a.takenAmount > infantry_b.takenAmount && infantry_a.takenAmount > cavalry_b.takenAmount
                                    || cavalry_a.takenAmount > infantry_b.takenAmount && cavalry_a.takenAmount > cavalry_b.takenAmount
                                    || archers_a.takenAmount > infantry_b.takenAmount && archers_a.takenAmount > cavalry_b.takenAmount
                                    || infantry_a.takenAmount > infantry_b.takenAmount && infantry_a.takenAmount > archers_b.takenAmount && cavalry_a.takenAmount > infantry_b.takenAmount && cavalry_a.takenAmount > archers_b.takenAmount && archers_a.takenAmount > infantry_b.takenAmount && archers_a.takenAmount > archers_b.takenAmount
                                    || infantry_a.takenAmount > infantry_b.takenAmount && infantry_a.takenAmount > archers_b.takenAmount && cavalry_a.takenAmount > infantry_b.takenAmount && cavalry_a.takenAmount > archers_b.takenAmount
                                    || infantry_a.takenAmount > infantry_b.takenAmount && infantry_a.takenAmount > archers_b.takenAmount && archers_a.takenAmount > infantry_b.takenAmount && archers_a.takenAmount > archers_b.takenAmount
                                    || cavalry_a.takenAmount > infantry_b.takenAmount && cavalry_a.takenAmount > archers_b.takenAmount && archers_a.takenAmount > infantry_b.takenAmount && archers_a.takenAmount > archers_b.takenAmount
                                    || infantry_a.takenAmount > infantry_b.takenAmount && infantry_a.takenAmount > archers_b.takenAmount
                                    || cavalry_a.takenAmount > infantry_b.takenAmount && cavalry_a.takenAmount > archers_b.takenAmount
                                    || archers_a.takenAmount > infantry_b.takenAmount && archers_a.takenAmount > archers_b.takenAmount
                                    || infantry_a.takenAmount > cavalry_b.takenAmount && infantry_a.takenAmount > archers_b.takenAmount && cavalry_a.takenAmount > cavalry_b.takenAmount && cavalry_a.takenAmount > archers_b.takenAmount && archers_a.takenAmount > cavalry_b.takenAmount && archers_a.takenAmount > archers_b.takenAmount
                                    || infantry_a.takenAmount > cavalry_b.takenAmount && infantry_a.takenAmount > archers_b.takenAmount && cavalry_a.takenAmount > cavalry_b.takenAmount && cavalry_a.takenAmount > archers_b.takenAmount
                                    || infantry_a.takenAmount > cavalry_b.takenAmount && infantry_a.takenAmount > archers_b.takenAmount && archers_a.takenAmount > cavalry_b.takenAmount && archers_a.takenAmount > archers_b.takenAmount
                                    || cavalry_a.takenAmount > cavalry_b.takenAmount && cavalry_a.takenAmount > archers_b.takenAmount && archers_a.takenAmount > cavalry_b.takenAmount && archers_a.takenAmount > archers_b.takenAmount
                                    || infantry_a.takenAmount > cavalry_b.takenAmount && infantry_a.takenAmount > archers_b.takenAmount
                                    || cavalry_a.takenAmount > cavalry_b.takenAmount && cavalry_a.takenAmount > archers_b.takenAmount
                                    || archers_a.takenAmount > cavalry_b.takenAmount && archers_a.takenAmount > archers_b.takenAmount
                                    || infantry_a.takenAmount > infantry_b.takenAmount && cavalry_a.takenAmount > infantry_b.takenAmount && archers_a.takenAmount > infantry_b.takenAmount
                                    || infantry_a.takenAmount > infantry_b.takenAmount && cavalry_a.takenAmount > infantry_b.takenAmount
                                    || infantry_a.takenAmount > infantry_b.takenAmount && archers_a.takenAmount > infantry_b.takenAmount
                                    || cavalry_a.takenAmount > infantry_b.takenAmount && archers_a.takenAmount > infantry_b.takenAmount
                                    || infantry_a.takenAmount > infantry_b.takenAmount
                                    || cavalry_a.takenAmount > infantry_b.takenAmount
                                    || archers_a.takenAmount > infantry_b.takenAmount
                                    || infantry_a.takenAmount > cavalry_b.takenAmount && cavalry_a.takenAmount > cavalry_b.takenAmount && archers_a.takenAmount > cavalry_b.takenAmount
                                    || infantry_a.takenAmount > cavalry_b.takenAmount && cavalry_a.takenAmount > cavalry_b.takenAmount
                                    || infantry_a.takenAmount > cavalry_b.takenAmount && archers_a.takenAmount > cavalry_b.takenAmount
                                    || cavalry_a.takenAmount > cavalry_b.takenAmount && archers_a.takenAmount > cavalry_b.takenAmount
                                    || infantry_a.takenAmount > cavalry_b.takenAmount
                                    || cavalry_a.takenAmount > cavalry_b.takenAmount
                                    || archers_a.takenAmount > cavalry_b.takenAmount
                                    || infantry_a.takenAmount > archers_b.takenAmount && cavalry_a.takenAmount > archers_b.takenAmount && archers_a.takenAmount > archers_b.takenAmount
                                    || infantry_a.takenAmount > archers_b.takenAmount && cavalry_a.takenAmount > archers_b.takenAmount
                                    || infantry_a.takenAmount > archers_b.takenAmount && archers_a.takenAmount > archers_b.takenAmount
                                    || cavalry_a.takenAmount > archers_b.takenAmount && archers_a.takenAmount > archers_b.takenAmount
                                    || infantry_a.takenAmount > archers_b.takenAmount
                                    || cavalry_a.takenAmount > archers_b.takenAmount
                                    || archers_a.takenAmount > archers_b.takenAmount)
                                {
                                    //If so 'Nic' gains provinces and 'Cos' loses provinces
                                    province_a += take;
                                    province_b -= take;
                                }

                                //Set player attack and AI defence to 'false'
                                atk_a = false;
                                def_b = 0;

                            } 
                            //Is the player attacking , but the AI not defending
                            else if (atk_a == true && def_b == 0)
                            {
                                //If so 'Nic' gets provinces and 'Cos' loses provinces
                                province_a += take;
                                province_b -= take;

                                //Sets player attack to false
                                atk_a = false;
                            }
                            //Is the AI defending, but the player not attacking
                            else if (atk_a == false && def_b == 1)
                            {
                                //If so, set AI defense to false
                                def_b = 0;
                            }
                            //Same as above, now the player is defending
                            if (atk_b == 1 && def_a == true)
                            {
                                double lostinf_a = infbreak_a - infbreak_b;
                                double lostinf2_a = infrange_a - infrange_b;
                                double lostinf3_a = infspeed_a - infspeed_b;
                                double lostinf4_a = infbreak_a - cavbreak_b;
                                double lostinf5_a = infrange_a - cavrange_b;
                                double lostinf6_a = infspeed_a - cavspeed_b;
                                double lostinf7_a = infbreak_a - arcbreak_b;
                                double lostinf8_a = infrange_a - arcrange_b;
                                double lostinf9_a = infspeed_a - arcspeed_b;
                                double lostcav_a = cavbreak_a - infbreak_b;
                                double lostcav2_a = cavrange_a - infrange_b;
                                double lostcav3_a = cavspeed_a - infspeed_b;
                                double lostcav4_a = cavbreak_a - cavbreak_b;
                                double lostcav5_a = cavrange_a - cavrange_b;
                                double lostcav6_a = cavspeed_a - cavspeed_b;
                                double lostcav7_a = cavbreak_a - arcbreak_b;
                                double lostcav8_a = cavrange_a - arcrange_b;
                                double lostcav9_a = cavspeed_a - arcspeed_b;
                                double lostarc_a = arcbreak_a - infbreak_b;
                                double lostarc2_a = arcrange_a - infrange_b;
                                double lostarc3_a = arcspeed_a - infspeed_b;
                                double lostarc4_a = arcbreak_a - cavbreak_b;
                                double lostarc5_a = arcrange_a - cavrange_b;
                                double lostarc6_a = arcspeed_a - cavspeed_b;
                                double lostarc7_a = arcbreak_a - arcbreak_b;
                                double lostarc8_a = arcrange_a - arcrange_b;
                                double lostarc9_a = arcspeed_a - arcspeed_b;

                                int lostinfTotal_a = (Convert.ToInt32(lostinf_a) + Convert.ToInt32(lostinf2_a) + Convert.ToInt32(lostinf3_a) + Convert.ToInt32(lostinf4_a) + Convert.ToInt32(lostinf5_a) + Convert.ToInt32(lostinf6_a) + Convert.ToInt32(lostinf7_a) + Convert.ToInt32(lostinf8_a) + Convert.ToInt32(lostinf9_a)) / 9;
                                int lostcavTotal_a = (Convert.ToInt32(lostcav_a) + Convert.ToInt32(lostcav2_a) + Convert.ToInt32(lostcav3_a) + Convert.ToInt32(lostcav4_a) + Convert.ToInt32(lostcav5_a) + Convert.ToInt32(lostcav6_a) + Convert.ToInt32(lostcav7_a) + Convert.ToInt32(lostcav8_a) + Convert.ToInt32(lostcav9_a)) / 9;
                                int lostarcTotal_a = (Convert.ToInt32(lostarc_a) + Convert.ToInt32(lostarc2_a) + Convert.ToInt32(lostarc3_a) + Convert.ToInt32(lostarc4_a) + Convert.ToInt32(lostarc5_a) + Convert.ToInt32(lostarc6_a) + Convert.ToInt32(lostarc7_a) + Convert.ToInt32(lostarc8_a) + Convert.ToInt32(lostarc9_a)) / 9;

                                if (lostinfTotal_a <= 0)
                                {
                                    lostinfTotal_a = 0;
                                }
                                if (lostcavTotal_a <= 0)
                                {
                                    lostcavTotal_a = 0;
                                }
                                if (lostarcTotal_a <= 0)
                                {
                                    lostarcTotal_a = 0;
                                }

                                infantry_a.takenAmount -= lostinfTotal_a;
                                cavalry_a.takenAmount -= lostcavTotal_a;
                                archers_a.takenAmount -= lostarcTotal_a;

                                double lostinf_b = infbreak_b - infbreak_a;
                                double lostinf2_b = infrange_b - infrange_a;
                                double lostinf3_b = infspeed_b - infspeed_a;
                                double lostinf4_b = infbreak_b - cavbreak_a;
                                double lostinf5_b = infrange_b - cavrange_a;
                                double lostinf6_b = infspeed_b - cavspeed_a;
                                double lostinf7_b = infbreak_b - arcbreak_a;
                                double lostinf8_b = infrange_b - arcrange_a;
                                double lostinf9_b = infspeed_b - arcspeed_a;
                                double lostcav_b = cavbreak_b - infbreak_a;
                                double lostcav2_b = cavrange_b - infrange_a;
                                double lostcav3_b = cavspeed_b - infspeed_a;
                                double lostcav4_b = cavbreak_b - cavbreak_a;
                                double lostcav5_b = cavrange_b - cavrange_a;
                                double lostcav6_b = cavspeed_b - cavspeed_a;
                                double lostcav7_b = cavbreak_b - arcbreak_a;
                                double lostcav8_b = cavrange_b - arcrange_a;
                                double lostcav9_b = cavspeed_b - arcspeed_a;
                                double lostarc_b = arcbreak_b - infbreak_a;
                                double lostarc2_b = arcrange_b - infrange_a;
                                double lostarc3_b = arcspeed_b - infspeed_a;
                                double lostarc4_b = arcbreak_b - cavbreak_a;
                                double lostarc5_b = arcrange_b - cavrange_a;
                                double lostarc6_b = arcspeed_b - cavspeed_a;
                                double lostarc7_b = arcbreak_b - arcbreak_a;
                                double lostarc8_b = arcrange_b - arcrange_a;
                                double lostarc9_b = arcspeed_b - arcspeed_a;

                                int lostinfTotal_b = (Convert.ToInt32(lostinf_b) + Convert.ToInt32(lostinf2_b) + Convert.ToInt32(lostinf3_b) + Convert.ToInt32(lostinf4_b) + Convert.ToInt32(lostinf5_b) + Convert.ToInt32(lostinf6_b) + Convert.ToInt32(lostinf7_b) + Convert.ToInt32(lostinf8_b) + Convert.ToInt32(lostinf9_b)) / 9;
                                int lostcavTotal_b = (Convert.ToInt32(lostcav_b) + Convert.ToInt32(lostcav2_b) + Convert.ToInt32(lostcav3_b) + Convert.ToInt32(lostcav4_b) + Convert.ToInt32(lostcav5_b) + Convert.ToInt32(lostcav6_b) + Convert.ToInt32(lostcav7_b) + Convert.ToInt32(lostcav8_b) + Convert.ToInt32(lostcav9_b)) / 9;
                                int lostarcTotal_b = (Convert.ToInt32(lostarc_b) + Convert.ToInt32(lostarc2_b) + Convert.ToInt32(lostarc3_b) + Convert.ToInt32(lostarc4_b) + Convert.ToInt32(lostarc5_b) + Convert.ToInt32(lostarc6_b) + Convert.ToInt32(lostarc7_b) + Convert.ToInt32(lostarc8_b) + Convert.ToInt32(lostarc9_b)) / 9;

                                if (lostinfTotal_b <= 0)
                                {
                                    lostinfTotal_b = 0;
                                }
                                if (lostcavTotal_b <= 0)
                                {
                                    lostcavTotal_b = 0;
                                }
                                if (lostarcTotal_b <= 0)
                                {
                                    lostarcTotal_b = 0;
                                }

                                infantry_a.takenAmount -= lostinfTotal_b;
                                cavalry_a.takenAmount -= lostcavTotal_b;
                                archers_a.takenAmount -= lostarcTotal_b;

                                if (infantry_a.takenAmount < infantry_b.takenAmount && infantry_a.takenAmount < cavalry_b.takenAmount && infantry_a.takenAmount < archers_b.takenAmount && cavalry_a.takenAmount < infantry_b.takenAmount && cavalry_a.takenAmount < cavalry_b.takenAmount && cavalry_a.takenAmount < archers_b.takenAmount && archers_a.takenAmount < infantry_b.takenAmount && archers_a.takenAmount < cavalry_b.takenAmount && archers_a.takenAmount < archers_b.takenAmount
                                    || infantry_a.takenAmount < infantry_b.takenAmount && infantry_a.takenAmount < cavalry_b.takenAmount && infantry_a.takenAmount < archers_b.takenAmount && cavalry_a.takenAmount < infantry_b.takenAmount && cavalry_a.takenAmount < cavalry_b.takenAmount && cavalry_a.takenAmount < archers_b.takenAmount
                                    || infantry_a.takenAmount < infantry_b.takenAmount && infantry_a.takenAmount < cavalry_b.takenAmount && infantry_a.takenAmount < archers_b.takenAmount && archers_a.takenAmount < infantry_b.takenAmount && archers_a.takenAmount < cavalry_b.takenAmount && archers_a.takenAmount < archers_b.takenAmount
                                    || cavalry_a.takenAmount < infantry_b.takenAmount && cavalry_a.takenAmount < cavalry_b.takenAmount && cavalry_a.takenAmount < archers_b.takenAmount && archers_a.takenAmount < infantry_b.takenAmount && archers_a.takenAmount < cavalry_b.takenAmount && archers_a.takenAmount < archers_b.takenAmount
                                    || infantry_a.takenAmount < infantry_b.takenAmount && infantry_a.takenAmount < cavalry_b.takenAmount && infantry_a.takenAmount < archers_b.takenAmount
                                    || cavalry_a.takenAmount < infantry_b.takenAmount && cavalry_a.takenAmount < cavalry_b.takenAmount && cavalry_a.takenAmount < archers_b.takenAmount
                                    || archers_a.takenAmount < infantry_b.takenAmount && archers_a.takenAmount < cavalry_b.takenAmount && archers_a.takenAmount < archers_b.takenAmount
                                    || infantry_a.takenAmount < infantry_b.takenAmount && infantry_a.takenAmount < cavalry_b.takenAmount && cavalry_a.takenAmount < infantry_b.takenAmount && cavalry_a.takenAmount < cavalry_b.takenAmount && archers_a.takenAmount < infantry_b.takenAmount && archers_a.takenAmount < cavalry_b.takenAmount
                                    || infantry_a.takenAmount < infantry_b.takenAmount && infantry_a.takenAmount < cavalry_b.takenAmount && cavalry_a.takenAmount < infantry_b.takenAmount && cavalry_a.takenAmount < cavalry_b.takenAmount
                                    || infantry_a.takenAmount < infantry_b.takenAmount && infantry_a.takenAmount < cavalry_b.takenAmount && archers_a.takenAmount < infantry_b.takenAmount && archers_a.takenAmount < cavalry_b.takenAmount
                                    || cavalry_a.takenAmount < infantry_b.takenAmount && cavalry_a.takenAmount < cavalry_b.takenAmount && archers_a.takenAmount < infantry_b.takenAmount && archers_a.takenAmount < cavalry_b.takenAmount
                                    || infantry_a.takenAmount < infantry_b.takenAmount && infantry_a.takenAmount < cavalry_b.takenAmount
                                    || cavalry_a.takenAmount < infantry_b.takenAmount && cavalry_a.takenAmount < cavalry_b.takenAmount
                                    || archers_a.takenAmount < infantry_b.takenAmount && archers_a.takenAmount < cavalry_b.takenAmount
                                    || infantry_a.takenAmount < infantry_b.takenAmount && infantry_a.takenAmount < archers_b.takenAmount && cavalry_a.takenAmount < infantry_b.takenAmount && cavalry_a.takenAmount < archers_b.takenAmount && archers_a.takenAmount < infantry_b.takenAmount && archers_a.takenAmount < archers_b.takenAmount
                                    || infantry_a.takenAmount < infantry_b.takenAmount && infantry_a.takenAmount < archers_b.takenAmount && cavalry_a.takenAmount < infantry_b.takenAmount && cavalry_a.takenAmount < archers_b.takenAmount
                                    || infantry_a.takenAmount < infantry_b.takenAmount && infantry_a.takenAmount < archers_b.takenAmount && archers_a.takenAmount < infantry_b.takenAmount && archers_a.takenAmount < archers_b.takenAmount
                                    || cavalry_a.takenAmount < infantry_b.takenAmount && cavalry_a.takenAmount < archers_b.takenAmount && archers_a.takenAmount < infantry_b.takenAmount && archers_a.takenAmount < archers_b.takenAmount
                                    || infantry_a.takenAmount < infantry_b.takenAmount && infantry_a.takenAmount < archers_b.takenAmount
                                    || cavalry_a.takenAmount < infantry_b.takenAmount && cavalry_a.takenAmount < archers_b.takenAmount
                                    || archers_a.takenAmount < infantry_b.takenAmount && archers_a.takenAmount < archers_b.takenAmount
                                    || infantry_a.takenAmount < cavalry_b.takenAmount && infantry_a.takenAmount < archers_b.takenAmount && cavalry_a.takenAmount < cavalry_b.takenAmount && cavalry_a.takenAmount < archers_b.takenAmount && archers_a.takenAmount < cavalry_b.takenAmount && archers_a.takenAmount < archers_b.takenAmount
                                    || infantry_a.takenAmount < cavalry_b.takenAmount && infantry_a.takenAmount < archers_b.takenAmount && cavalry_a.takenAmount < cavalry_b.takenAmount && cavalry_a.takenAmount < archers_b.takenAmount
                                    || infantry_a.takenAmount < cavalry_b.takenAmount && infantry_a.takenAmount < archers_b.takenAmount && archers_a.takenAmount < cavalry_b.takenAmount && archers_a.takenAmount < archers_b.takenAmount
                                    || cavalry_a.takenAmount < cavalry_b.takenAmount && cavalry_a.takenAmount < archers_b.takenAmount && archers_a.takenAmount < cavalry_b.takenAmount && archers_a.takenAmount < archers_b.takenAmount
                                    || infantry_a.takenAmount < cavalry_b.takenAmount && infantry_a.takenAmount < archers_b.takenAmount
                                    || cavalry_a.takenAmount < cavalry_b.takenAmount && cavalry_a.takenAmount < archers_b.takenAmount
                                    || archers_a.takenAmount < cavalry_b.takenAmount && archers_a.takenAmount < archers_b.takenAmount
                                    || infantry_a.takenAmount < infantry_b.takenAmount && cavalry_a.takenAmount < infantry_b.takenAmount && archers_a.takenAmount < infantry_b.takenAmount
                                    || infantry_a.takenAmount < infantry_b.takenAmount && cavalry_a.takenAmount < infantry_b.takenAmount
                                    || infantry_a.takenAmount < infantry_b.takenAmount && archers_a.takenAmount < infantry_b.takenAmount
                                    || cavalry_a.takenAmount < infantry_b.takenAmount && archers_a.takenAmount < infantry_b.takenAmount
                                    || infantry_a.takenAmount < infantry_b.takenAmount
                                    || cavalry_a.takenAmount < infantry_b.takenAmount
                                    || archers_a.takenAmount < infantry_b.takenAmount
                                    || infantry_a.takenAmount < cavalry_b.takenAmount && cavalry_a.takenAmount < cavalry_b.takenAmount && archers_a.takenAmount < cavalry_b.takenAmount
                                    || infantry_a.takenAmount < cavalry_b.takenAmount && cavalry_a.takenAmount < cavalry_b.takenAmount
                                    || infantry_a.takenAmount < cavalry_b.takenAmount && archers_a.takenAmount < cavalry_b.takenAmount
                                    || cavalry_a.takenAmount < cavalry_b.takenAmount && archers_a.takenAmount < cavalry_b.takenAmount
                                    || infantry_a.takenAmount < cavalry_b.takenAmount
                                    || cavalry_a.takenAmount < cavalry_b.takenAmount
                                    || archers_a.takenAmount < cavalry_b.takenAmount
                                    || infantry_a.takenAmount < archers_b.takenAmount && cavalry_a.takenAmount < archers_b.takenAmount && archers_a.takenAmount < archers_b.takenAmount
                                    || infantry_a.takenAmount < archers_b.takenAmount && cavalry_a.takenAmount < archers_b.takenAmount
                                    || infantry_a.takenAmount < archers_b.takenAmount && archers_a.takenAmount < archers_b.takenAmount
                                    || cavalry_a.takenAmount < archers_b.takenAmount && archers_a.takenAmount < archers_b.takenAmount
                                    || infantry_a.takenAmount < archers_b.takenAmount
                                    || cavalry_a.takenAmount < archers_b.takenAmount
                                    || archers_a.takenAmount < archers_b.takenAmount)
                                {
                                    province_a -= take;
                                    province_b += take;
                                }

                                atk_b = 0;
                                def_a = false;
                            }
                            else if (atk_b == 1 && def_a == false)
                            {
                                province_a -= take;
                                province_b += take;

                                atk_b = 0;
                            }
                            else if (atk_b == 0 && def_a == true)
                            {

                                def_a = false;
                            }

                            //Returns the (division)_a.takenAmount value to (division)_a.amount. Sets (division)_a.takenAmount to 0
                            infantry_a.amount += infantry_a.takenAmount;
                            infantry_a.takenAmount = 0;
                            archers_a.amount += archers_a.takenAmount;
                            archers_a.takenAmount = 0;
                            cavalry_a.amount += cavalry_a.takenAmount;
                            cavalry_a.takenAmount = 0;

                            infantry_b.amount += infantry_b.takenAmount;
                            infantry_b.takenAmount = 0;
                            archers_b.amount += archers_b.takenAmount;
                            archers_b.takenAmount = 0;
                            cavalry_b.amount += cavalry_b.takenAmount;
                            cavalry_b.takenAmount = 0;

                            //Resums army_a
                            army_a = archers_a.amount + infantry_a.amount + cavalry_a.amount;

                            //Resums recruitable
                            recruitable_a += recruitmentChance_a;
                            recruitable_b += recruitmentChance_b;

                            recruitment_a = (1000 * province_a) / 10;
                            recruitment_b = (1000 * province_b) / 10;

                            if (recruitable_a > recruitment_a)
                            {
                                recruitable_a = recruitment_a;
                            }
                            if (recruitable_b > recruitment_b)
                            {
                                recruitable_b = recruitment_b;
                            }

                            infantry_b.recruited = 0;
                            archers_b.recruited = 0;
                            cavalry_b.recruited = 0;
                            Thread.Sleep(500);
                            
                        }
                        else
                        {
                            Console.WriteLine("Invalid input");
                        }
                        if (date == 50)
                        {
                            break;
                        }
                        else if (unrest == 100)
                        {
                            break;
                        }
                        //The memes
                        if (memeMode == true)
                        {
                            if (choice == "sex" || choice == "Sex")
                            {
                                int seg = rng.Next(1, 11);
                                if (seg == 1)
                                {
                                    Console.WriteLine("You layed with your queen");
                                    recruitable_a += 1;
                                }
                                else
                                {
                                    Console.WriteLine("You try to have sex. Unfortunately for you, you are bitchless");
                                }
                            }
                            else if (choice == "hoi" || choice == "Hoi")
                            {
                                Console.WriteLine("You decided to play Hearts of Iron 4. You managed to get 10 more infantry");
                                infantry_a.amount += 10;
                                army_a = infantry_a.amount + cavalry_a.amount + archers_a.amount;
                            }
                            else if (choice == "fumo" || choice == "Fumo")
                            {
                                Console.WriteLine("The Fumo calmed your nerves");
                                ap += 10;
                            }
                            else if (choice == "wock" || choice == "Wock")
                            {
                                Console.WriteLine("You took the wock to Poland. Your peasants enjoyed that");
                                unrest -= 30;
                            }
                        }
                        Console.WriteLine("You are back in your bedroom");
                        Console.WriteLine("What will you do?");
                    } while (true);
                } 
            
            }while (true);
            
        }
    }
}//hhhhhhhhhhhhhhhhhhhhhhhnnnnnnnnnnnnnnnnnnnnnnnnnggggggggggggggggggggggggggggggggg